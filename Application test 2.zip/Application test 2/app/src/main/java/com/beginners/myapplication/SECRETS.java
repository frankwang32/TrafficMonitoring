package com.beginners.myapplication;
        public class SECRETS {
            public static final String CLIENT_KEY = "k3mfKfFVsQNQqJM6ELPqv9HQN?0BM9RNFxX.fT-4";
            public static final String CLIENT_SECRET = "4-GwUZL8JK:DU6qWSuwbVh?18-bV.Ab?PVn!Cg381KArd-l.cwLB:u2;stmg?gL!rUZH=_mYCwGq:vfmqFs9?p7fvYWL4fHCVnu@p2NQv;;tVDA_:UkwkZq-2::w4yhn";
        }