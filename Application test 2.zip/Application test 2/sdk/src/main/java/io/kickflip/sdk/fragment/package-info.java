/**
 * The Kickflip fragments contain the meat of the interaction between
 * the Android application lifecycle and the SDK components.
 **/
package io.kickflip.sdk.fragment;