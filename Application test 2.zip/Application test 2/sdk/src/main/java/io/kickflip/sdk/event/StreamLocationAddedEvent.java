package io.kickflip.sdk.event;

/**
 * Created by davidbrodsky on 3/11/14.
 */
public class StreamLocationAddedEvent {
}
