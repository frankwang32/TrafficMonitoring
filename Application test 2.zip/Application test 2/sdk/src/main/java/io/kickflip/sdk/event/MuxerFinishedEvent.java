package io.kickflip.sdk.event;

/**
 * Created by davidbrodsky on 2/18/14.
 */
public class MuxerFinishedEvent {
}
