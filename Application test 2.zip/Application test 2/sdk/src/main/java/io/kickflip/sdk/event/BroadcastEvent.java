package io.kickflip.sdk.event;

/**
 * Created by davidbrodsky on 1/28/14.
 */
public class BroadcastEvent {
}
