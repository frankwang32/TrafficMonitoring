package io.kickflip.sdk.event;

/**
 * Created by davidbrodsky on 2/21/14.
 */
public class BroadcastIsBufferingEvent extends BroadcastEvent {
}
